module.exports = {
    name: 'sc',
    cmd: ['sc'],
    category: 'other',
    async handler(m, {conn}){
        m.reply(`-`)
    }
}